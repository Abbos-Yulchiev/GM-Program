package sortingAndBinarySearchTogether;


//TODO -> {after the understand the requirement need to implement the solution}
public class SortAndBinarySearch {
}
