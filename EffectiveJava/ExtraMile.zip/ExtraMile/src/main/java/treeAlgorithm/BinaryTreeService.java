package treeAlgorithm;

//TODO need to clarify what is bypass algorithm then implement the solution
public class BinaryTreeService {
}
