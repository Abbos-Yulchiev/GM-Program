### Binary search

* In both recursively and iteratively search works O(log n) time complexity
* The iterative version of binary searching uses constant amount space, space complexity O(1)
* While recursive version has O(log n) space complexity
* Recursive version of binary search may be easy to implement, while iterative version is effective